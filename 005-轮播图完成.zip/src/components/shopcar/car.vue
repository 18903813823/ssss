<template lang="html">
    <div class="temp">
        购物车
    </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
